 #!/bin/bash
 ./load_chem_app/load_chem_app
